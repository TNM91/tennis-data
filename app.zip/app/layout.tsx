import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import Image from "next/image";
import Link from "next/link";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: {
    default: "TenAceIQ",
    template: "%s | TenAceIQ",
  },
  description:
    "Know more. Plan better. Compete smarter. Ratings, rankings, matchup insights, and captain tools for competitive tennis.",
};

function BrandWordmark({ header = false, footer = false }: { header?: boolean; footer?: boolean }) {
  const iconSize = header ? 74 : footer ? 54 : 44;
  const textSize = header ? "text-[2rem]" : footer ? "text-[1.6rem]" : "text-[1.25rem]";

  return (
    <div className="flex items-center gap-3">
      <Image
        src="/logo-icon.png"
        alt="TenAceIQ"
        width={iconSize}
        height={iconSize}
        priority={header}
        className="h-auto w-auto object-contain"
      />
      <div
        className={`${textSize} flex items-center font-black leading-none tracking-[-0.05em]`}
      >
        <span className="text-white">TenAce</span>
        <span className="ml-1 bg-gradient-to-r from-lime-300 via-green-300 to-emerald-400 bg-clip-text text-transparent">
          IQ
        </span>
      </div>
    </div>
  );
}

function NavLink({
  href,
  label,
}: {
  href: string;
  label: string;
}) {
  return (
    <Link
      href={href}
      className="rounded-full border border-white/12 bg-white/6 px-4 py-2 text-sm font-semibold text-white/82 transition hover:border-blue-300/35 hover:bg-white/10 hover:text-white"
    >
      {label}
    </Link>
  );
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full bg-[#061120] text-white">
        <div className="relative min-h-screen overflow-x-hidden bg-[radial-gradient(circle_at_top,_rgba(37,99,235,0.28),_transparent_34%),linear-gradient(180deg,_#081427_0%,_#09172a_42%,_#07111f_100%)]">
          <div className="pointer-events-none absolute inset-0 opacity-60">
            <div className="absolute left-[-12rem] top-[-10rem] h-[28rem] w-[28rem] rounded-full bg-blue-500/18 blur-3xl" />
            <div className="absolute right-[-10rem] top-[8rem] h-[24rem] w-[24rem] rounded-full bg-cyan-400/10 blur-3xl" />
            <div className="absolute bottom-[-10rem] left-1/2 h-[24rem] w-[24rem] -translate-x-1/2 rounded-full bg-lime-400/8 blur-3xl" />
          </div>

          <header className="sticky top-0 z-50 border-b border-white/10 bg-[#07111fd9] backdrop-blur-xl">
            <div className="mx-auto flex min-h-[94px] w-full max-w-7xl items-center justify-between gap-6 px-4 py-4 sm:px-6 lg:px-8">
              <Link href="/" className="shrink-0">
                <BrandWordmark header />
              </Link>

              <nav className="hidden flex-wrap items-center justify-end gap-3 md:flex">
                <NavLink href="/" label="Home" />
                <NavLink href="/rankings" label="Rankings" />
                <NavLink href="/matchup" label="Matchup" />
                <NavLink href="/add-match" label="Add Match" />
                <NavLink href="/csv-import" label="CSV Import" />
                <NavLink href="/paste-results" label="Paste Results" />
                <NavLink href="/manage-matches" label="Manage Matches" />
                <NavLink href="/manage-players" label="Manage Players" />
              </nav>
            </div>

            <div className="mx-auto flex w-full max-w-7xl gap-2 overflow-x-auto px-4 pb-4 md:hidden sm:px-6 lg:px-8">
              <NavLink href="/" label="Home" />
              <NavLink href="/rankings" label="Rankings" />
              <NavLink href="/matchup" label="Matchup" />
              <NavLink href="/add-match" label="Add Match" />
              <NavLink href="/csv-import" label="CSV Import" />
            </div>
          </header>

          <main className="relative z-10">{children}</main>

          <footer className="relative z-10 mt-20 border-t border-white/10 bg-black/10">
            <div className="mx-auto flex w-full max-w-7xl flex-col gap-8 px-4 py-10 sm:px-6 lg:px-8 md:flex-row md:items-center md:justify-between">
              <div className="flex flex-col gap-3">
                <BrandWordmark footer />
                <p className="max-w-xl text-sm text-white/58">
                  Know more. Plan better. Compete smarter.
                </p>
              </div>

              <div className="flex flex-wrap gap-3">
                <NavLink href="/rankings" label="Rankings" />
                <NavLink href="/matchup" label="Matchup" />
                <NavLink href="/manage-players" label="Manage Players" />
              </div>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}